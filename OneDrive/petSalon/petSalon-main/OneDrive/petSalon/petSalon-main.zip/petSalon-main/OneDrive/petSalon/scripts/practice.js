//object Literals
let student1 = {
    name:"jon Smith",
    age:99,
    isAdmin:false,
    grade1:3.7
}

console.log(student1);

